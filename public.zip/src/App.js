import React from "react";
import RegistrationForm from "../src/component/RegistrationForm"
import LoginForm from "../src/component/LoginForm";

const App = () => {
  return <div>
    <RegistrationForm />
    <LoginForm />
    </div>;
};

export default App;
